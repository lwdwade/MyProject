## 0.2.0 - First Release
* Every feature added
* Every bug fixed
