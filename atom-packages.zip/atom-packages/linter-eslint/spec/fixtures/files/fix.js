const x = 6;
function foo() {
 console.log(x)
}

foo()
