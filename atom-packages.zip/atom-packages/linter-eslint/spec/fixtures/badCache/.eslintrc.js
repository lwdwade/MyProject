module.exports = {
  root: true,
  rules: {
    'no-undef': 'error'
  }
}
