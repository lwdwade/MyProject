'use strict';

function foo() {
  return 42;

  var a = 4;
  return a + 2;
}
