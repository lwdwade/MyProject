module.exports = {
  root: true,
  rules: {
    'no-console': 'error',
    'no-trailing-spaces': 'error'
  }
}
