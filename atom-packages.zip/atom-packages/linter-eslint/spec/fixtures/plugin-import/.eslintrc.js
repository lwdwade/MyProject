module.exports = {
  // root: true,
  plugins: [
    'import'
  ],
  rules: {
    'import/newline-after-import': 'error'
  }
}
