const setting = {
  state: {
    mainTheme: {
      dark: false
    },
    primaryDrawer: {
      model: true,
      type: 'default (no property)',
      clipped: true,
      floating: false,
      mini: false
    },
    footerTheme: {
      inset: false
    }
  },
  mutations: {
    SETDARK (state, status) {
      state.mainTheme.dark = status
    },
    SETDRAWER (state, status) {
      state.primaryDrawer.model = !state.primaryDrawer.model
    },
    SETCLIPPED (state, status) {
      state.primaryDrawer.clipped = status
    },
    SETFLOATING (state, status) {
      state.primaryDrawer.floating = status
    },
    SETMINI (state, status) {
      state.primaryDrawer.mini = status
    },
    SETINSET (state, status) {
      state.footerTheme.inset = status
    }
  },
  actions: {
    setDark ({ commit }, status) {
      commit('SETDARK', status)
    },
    setDrawer ({ commit }, status) {
      commit('SETDRAWER', status)
    },
    setClipped ({ commit }, status) {
      commit('SETCLIPPED', status)
    },
    setMini ({ commit }, status) {
      commit('SETMINI', status)
    },
    setFloating ({ commit }, status) {
      commit('SETFLOATING', status)
    },
    setInset ({ commit }, status) {
      commit('SETINSET', status)
    }
  }
}

export default setting
