
const getters = {
  mainTheme: state => state.setting.mainTheme,
  primaryDrawer: state => state.setting.primaryDrawer,
  footerTheme: state => state.setting.footerTheme
}
export default getters
