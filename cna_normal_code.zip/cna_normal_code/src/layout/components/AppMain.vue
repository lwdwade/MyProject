<template>
  <v-content>
    <v-container fluid>
    <router-view></router-view>
    </v-container>
  </v-content>
</template>

<script>

export default {
  name: 'AppMain',
  data () {
    return {
      //
    }
  }
}
</script>
