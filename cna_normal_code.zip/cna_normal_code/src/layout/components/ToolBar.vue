<template>
  <v-toolbar :clipped-left="primaryDrawer.clipped" app >
    <v-toolbar-side-icon
      v-if="primaryDrawer.type !== 'permanent'"
      @click.stop="primaryDrawer.model = !primaryDrawer.model"
    >
    </v-toolbar-side-icon>
    <v-toolbar-title>
      <span class="title ml-3 mr-5">HSBC&nbsp;<span class="text">CNA</span></span>
    </v-toolbar-title>
    <v-spacer></v-spacer>
    <v-layout row align-center style="max-width: 550px" class="mr-5">
      <v-text-field
        placeholder="Search..."
        single-line
        append-icon="search"
        :append-icon-cb="() => {}"
        hide-details
      ></v-text-field>
    </v-layout>
    <!-- <v-spacer></v-spacer> -->
    <v-btn icon>
      <v-icon>apps</v-icon>
    </v-btn>
    <v-btn icon>
      <v-icon>notifications</v-icon>
    </v-btn>
    <v-btn icon large>
      <v-avatar size="32px" tile>
        <span>V</span>
      </v-avatar>
    </v-btn>
  </v-toolbar>
</template>

<script>

export default {
  name: 'ToolBar',
  data: () => ({ }),
  computed: {
    primaryDrawer () {
      return this.$store.getters.primaryDrawer
    }
  },
  medthods: {
    setDrawer () {
      this.$store.dispatch('setDrawer')
    }
  }
}
</script>
