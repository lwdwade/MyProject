<template>
  <v-footer :inset="footerTheme.inset" app>
    <span class="px-3">&copy; {{ new Date().getFullYear() }}</span>
  </v-footer>
</template>

<script>

export default {
  name: 'Footer',
  data: () => ({ }),
  computed: {
    footerTheme () {
      return this.$store.getters.footerTheme
    }
  }
}
</script>
