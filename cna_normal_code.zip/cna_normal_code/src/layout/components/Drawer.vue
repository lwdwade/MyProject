<template>
  <v-navigation-drawer
    v-model="primaryDrawer.model"
    :permanent="primaryDrawer.type === 'permanent'"
    :temporary="primaryDrawer.type === 'temporary'"
    :clipped="primaryDrawer.clipped"
    :floating="primaryDrawer.floating"
    :mini-variant="primaryDrawer.mini"
    :absolute="primaryDrawer.floating"
    overflow
    app
    >
    <v-layout column align-center>
      <v-flex class="mt-4">
         <v-avatar size="150">
           <img
            :src="logo"
            alt="HSBC_LOGO"
          />
         </v-avatar>
      </v-flex>
    </v-layout>
    <v-list dense >

      <v-subheader class="mt-3 grey--text text--darken-1">Header</v-subheader>
      <v-list-tile v-for="item in items" :key="item.text" @click="">
        <v-list-tile-action>
          <v-icon>{{ item.icon }}</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>
            {{ item.text }}
          </v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>

      <v-subheader class="mt-3 grey--text text--darken-1">Custom theme variants</v-subheader>
      <v-list-tile to="/setting">
        <v-list-tile-action>
          <v-icon>settings</v-icon>
        </v-list-tile-action>
        <v-list-tile-content>
          <v-list-tile-title>
            Theme setting
          </v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>

    </v-list>
  </v-navigation-drawer>
</template>

<script>

export default {
  name: 'Drawer',
  data: () => ({
    logo: require('../../assets/hsbc_logo.png'),
    items: [
      { icon: 'trending_up', text: 'Most Popular' },
      { icon: 'subscriptions', text: 'Subscriptions' },
      { icon: 'history', text: 'History' },
      { icon: 'featured_play_list', text: 'Playlists' },
      { icon: 'watch_later', text: 'Watch Later' }
    ]
  }),
  computed: {
    primaryDrawer () {
      return this.$store.getters.primaryDrawer
    }
  }
}
</script>
