<template>
  <v-app :dark="mainTheme.dark">
    <Drawer/>
    <tool-bar/>
    <app-main/>
    <Footer/>
  </v-app>
</template>

<script>
import { ToolBar, Drawer, Footer, AppMain } from './components'

export default {
  name: 'Layout',
  components: {
    ToolBar,
    Drawer,
    Footer,
    AppMain
  },
  data: () => ({ }),
  computed: {
    mainTheme () {
      return this.$store.getters.mainTheme
    }
  }
}
</script>
