import Vue from 'vue'
import Router from 'vue-router'
import Layout from '../layout/Layout.vue'

const route = (path, file, name, children) => {
  return {
    exact: true,
    path,
    name,
    children,
    components: require(`../views/${file}.vue`)
  }
}
Vue.use(Router)

const router = new Router({
  base: __dirname,
  mode: 'hash',
  routes: [
    {
      path: '/',
      name: 'layout',
      component: Layout,
      redirect: 'home',
      children: [
        route('/home', 'Home', 'home', null),
        route('/setting', 'Setting', 'setting', null)
      ]
    }
  ]
})
export default router
