<template>
  <div>
    <v-btn class="primary">
      hello
    </v-btn>
  </div>
</template>

<script>

export default {
  name: 'Home',
  data () {
    return {
      //
    }
  }
}
</script>
