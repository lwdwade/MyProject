<template>
  <v-layout justify-center class="my-5 mb-5">
    <v-flex xs8>
      <v-card>
        <v-card-text>
          <v-layout row wrap>
            <v-flex xs12 md6>
              <span>Theme</span>
              <v-switch v-model="mainTheme.dark" primary label="Dark" @change="setDark"></v-switch>
            </v-flex>
            <v-flex xs12 md6>
              <span>Drawer</span>
              <v-radio-group v-model="primaryDrawer.type" column>
                <v-radio
                  v-for="drawer in drawers"
                  :key="drawer"
                  :label="drawer"
                  :value="drawer.toLowerCase()"
                  primary
                ></v-radio>
              </v-radio-group>
              <v-switch v-model="primaryDrawer.clipped" label="Clipped" primary @change="setClipped"></v-switch>
              <v-switch v-model="primaryDrawer.floating" label="Floating" primary @change="setFloating"></v-switch>
              <v-switch v-model="primaryDrawer.mini" label="Mini" primary @change="setMini"></v-switch>
            </v-flex>
            <v-flex xs12 md6>
              <span>Footer</span>
              <v-switch v-model="footerTheme.inset" label="Inset" primary @change="inset"></v-switch>
            </v-flex>
          </v-layout>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn flat>Cancel</v-btn>
          <v-btn flat color="primary">Submit</v-btn>
        </v-card-actions>
      </v-card>
    </v-flex>
  </v-layout>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'Home',
  data: () => ({
    drawers: ['Default (no property)', 'Permanent', 'Temporary']
  }),
  computed: {
    ...mapGetters([
      'mainTheme',
      'primaryDrawer',
      'footerTheme'
    ])
  },
  methods: {
    setDark (status) {
      this.$store.dispatch('setDark', status)
    },
    setClipped (status) {
      this.$store.dispatch('setClipped', status)
    },
    setMini (status) {
      this.$store.dispatch('setMini', status)
    },
    setFloating (status) {
      this.$store.dispatch('setFloating', status)
    },
    inset (status) {
      this.$store.dispatch('setInset', status)
    }
  }
}
</script>
