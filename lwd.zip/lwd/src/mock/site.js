import Mock from 'mockjs'
import { param2Obj } from '@/utils'

const List = []
const count = 100

const baseContent = 'siteList'
const image_uri = ''

for (let i = 0; i < count; i++) {
  List.push(Mock.mock({
    id: '@increment',
    timestamp: +Mock.Random.date('T'),
    author: '@first',
    reviewer: '@first',
    title: '@title(5, 10)',
    content_short: 'i am test data',
    content: baseContent,
    forecast: '@float(0, 100, 2, 2)',
    importance: '@integer(1, 3)',
    'type|1': ['CN', 'US', 'JP', 'EU'],
    'status|1': ['published', 'draft', 'deleted'],
    display_time: '@datetime',
    comment_disabled: true,
    pageviews: '@integer(300, 5000)',
    image_uri,
    platforms: ['a-platform']
  }))
}

export default {
  getSiteList: config => {
    const { role } = param2Obj(config.url)
    let siteList
    if (role === 'Inputter') {
      siteList = [
        { siteNme: 'hk', siteDetail: 'HSBC hk inputter' },
        { siteNme: 'cn', siteDetail: 'HSBC cn inputter' },
        { siteNme: 'my', siteDetail: 'HSBC my inputter' },
        { siteNme: 'ph', siteDetail: 'HSBC ph inputter' }
      ]
    }
    if (role === 'Approver') {
      siteList = [
        { siteNme: 'hk', siteDetail: 'HSBC hk approver' },
        { siteNme: 'cn', siteDetail: 'HSBC cn approver' },
        { siteNme: 'my', siteDetail: 'HSBC my approver' },
        { siteNme: 'ph', siteDetail: 'HSBC ph approver' }
      ]
    }
    return {
      items: siteList
    }
  }
}
