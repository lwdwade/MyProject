import request from '@/utils/request'

export function getSiteList(query) {
  return request({
    url: '/site/list',
    method: 'get',
    params: query
  })
}
