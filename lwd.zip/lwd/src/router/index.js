import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/views/layout/Layout'

export const constantRouterMap = [
  { path: '/login', component: () => import('@/views/login/index'), hidden: true },
  { path: '/404', component: () => import('@/views/errorPage/404'), hidden: true },
  { path: '/401', component: () => import('@/views/errorPage/401'), hidden: true },
  {
    path: '',
    component: Layout,
    redirect: '/home',
    children: [{ path: 'home', component: () => import('@/views/home/index'), name: 'home', meta: { title: 'Home', icon: 'el-icon-menu', noCache: true }}]
  }
]

export default new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
})

export const asyncRouterMap = [
  {
    path: '',
    component: Layout,
    redirect: 'noredirect',
    children: [
      { path: 'custlist', component: () => import('@/views/customer/CustList'), name: 'CustList', meta: { title: 'CustList', icon: 'el-icon-location' }}
      // { path: 'promptinglist/:id(\\d+)', component: () => import('@/views/customer/CustList'), name: 'CustList', meta: { title: 'CustList', icon: 'el-icon-location', noCache: true }, hidden: true }
    ]
  },
  {
    path: '',
    component: Layout,
    redirect: 'noredirect',
    children: [
      { path: 'custdetail', component: () => import('@/views/customer/CustDetail'), name: 'CustDetail', meta: { title: 'CustDetail', icon: 'el-icon-tickets' }}
    ]
  },
  { path: '*', redirect: '/404', hidden: true }
]
