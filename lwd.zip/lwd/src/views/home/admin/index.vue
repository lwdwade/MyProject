<template>
  <div class="app-container">
    <span>i am inputter</span>
    <br>
    <el-table :data="list" v-loading.body="listLoading" border fit highlight-current-row style="width: 100%">
      <el-table-column width="100px" align="center" label="siteName">
        <template slot-scope="scope">
          <span>{{scope.row.siteNme}}</span>
        </template>
      </el-table-column>
      <el-table-column min-width="300px" align="center" label="SiteLink">
        <template slot-scope="scope">
          <router-link class="link-type" :to="'/custlist'">
            <span>{{scope.row.siteDetail}}</span>
          </router-link>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { getSiteList } from '@/api/site'

export default {
  name: 'siteList',
  data() {
    return {
      list: null,
      user: {
        role: ''
      }
    }
  },
  created() {
    this.getList()
  },
  methods: {
    getList() {
      this.listLoading = true
      this.user.role = this.$store.getters.name
      getSiteList(this.user).then(response => {
        this.list = response.data.items
        this.listLoading = false
      })
    }
  }
}
</script>

<style scoped>
.edit-input {
  padding-right: 100px;
}
.cancel-btn {
  position: absolute;
  right: 15px;
  top: 10px;
}
</style>
