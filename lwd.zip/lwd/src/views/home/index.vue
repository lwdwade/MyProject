<template>
  <div class="home-container">
    <component :is="currentRole"></component>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import inputterhome from './admin'
import approverhome from './editor'

export default {
  name: 'home',
  components: { inputterhome, approverhome },
  data() {
    return {
      currentRole: 'inputterhome'
    }
  },
  computed: {
    ...mapGetters([
      'roles'
    ])
  },
  created() {
    if (!this.roles.includes('inputter')) {
      this.currentRole = 'approverhome'
    }
  }
}
</script>
