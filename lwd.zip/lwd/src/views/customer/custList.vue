<template>
  <prompting-list :is-edit='true'></prompting-list>
</template>

<script>
import PromptingList from './components/PromptingList'

export default {
  name: 'PtList',
  components: { PromptingList }
}
</script>
