<template>
  <div class="tab-container">
    <el-tag>mounted times ：{{createdTimes}}</el-tag>
    <el-tabs :tab-position="'right'"  style='margin-top:15px;' v-model="activeName">
      <el-tab-pane :label="'BasicMessage'" :key="'basicmsg'" :name="'basicmsg'">
        <keep-alive>
          <basic-message v-if="activeName=='basicmsg'" @create='showCreatedTimes'></basic-message>
        </keep-alive>
      </el-tab-pane>

      <el-tab-pane :label="'Facility'" :key="'fcty'" :name="'fcty'">
        <keep-alive>
          <facility v-if="activeName=='fcty'" @create='showCreatedTimes'></facility>
        </keep-alive>
      </el-tab-pane>

      <el-tab-pane :label="'Security'" :key="'sec'" :name="'sec'">
        <keep-alive>
          <security v-if="activeName=='sec'" @create='showCreatedTimes'></security>
        </keep-alive>
      </el-tab-pane>

      <el-tab-pane :label="'Restructure'" :key="'restr'" :name="'restr'">
        <keep-alive>
          <tab-pane v-if="activeName=='restr'" @create='showCreatedTimes'></tab-pane>
        </keep-alive>
      </el-tab-pane>
    </el-tabs>
    <el-button class="pan-btn blue-btn" to="/components/index">Components</el-button>

  </div>
</template>

<script>
import { tabPane, basicMessage, facility, security } from './components'

export default {
  name: 'tab',
  components: { tabPane, basicMessage, facility, security },
  data() {
    return {

      activeName: 'basicmsg',
      createdTimes: 0
    }
  },
  methods: {
    showCreatedTimes() {
      this.createdTimes = this.createdTimes + 1
    }
  }
}
</script>

<style scoped>
  .tab-container{
    margin: 30px;
  }
</style>
