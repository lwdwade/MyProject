<template>
  <div class="app-container">

    <el-table :data="list"
    v-loading.body="listLoading"
    border fit highlight-current-row style="width: 100%"
    @cell-dblclick="editCell"
>

      <el-table-column align="center" label="AAAAAA">
        <template slot-scope="scope">
            <div  >
            <el-input v-if="scope.row.edit" v-model='scope.row.author' @blur="aaaaa(scope.row)"></el-input>
            <span v-else>{{scope.row.author}}</span>
            </div>
        </template>
      </el-table-column>

      <el-table-column min-width="300px" label="Title">
        <template slot-scope="scope" @click='scope.row.edit'>
          <template v-if="scope.row.edit" >
            <el-input class="edit-input" size="small" v-model="scope.row.title" ></el-input>
            <el-button class='cancel-btn' size="small" icon="el-icon-refresh" type="warning" @click="cancelEdit(scope.row)">cancel</el-button>
          </template>
          <span v-else>{{ scope.row.title }}</span>
        </template>
      </el-table-column>

      <el-table-column align="center" label="Actions" width="120">
        <template slot-scope="scope">
          <el-button v-if="scope.row.edit" type="success" @click="confirmEdit(scope.row)" size="small" icon="el-icon-circle-check-outline">Ok</el-button>
          <el-button v-else type="primary" @click='scope.row.edit=!scope.row.edit' size="small" icon="el-icon-edit">Edit</el-button>
        </template>
      </el-table-column>

    </el-table>
  </div>
</template>

<script>
import { fetchList } from '@/api/article'

export default {
  name: 'inlineEditTable',
  data() {
    return {
      editable: [],
      list: null,
      listLoading: true,
      listQuery: {
        page: 1,
        limit: 10
      }
    }
  },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'info',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },
  created() {
    this.getList()
  },
  methods: {
    editCell(row, column, cell, event) {
      row.edit = true
    },
    exitEditCell(row, column, cell, event) {
      row.edit = false
    },
    aaaaa(row) {
      row.edit = false
    },
    // chengenum(row) {
    //   row.edit = true
    // },
    getList() {
      this.listLoading = true
      this.$emit('create')
      fetchList(this.listQuery).then(response => {
        const items = response.data.items
        this.list = items.map(v => {
          this.$set(v, 'edit', false)

          v.originalTitle = v.title

          return v
        })
        this.listLoading = false
      })
    },
    cancelEdit(row) {
      row.title = row.originalTitle
      row.edit = false
      this.$message({
        message: 'The title has been restored to the original value',
        type: 'warning'
      })
    },
    confirmEdit(row) {
      row.edit = false
      row.originalTitle = row.title
      this.$message({
        message: 'The title has been edited',
        type: 'success'
      })
    }
  }
}
</script>

<style scoped>
.edit-input {
  padding-right: 100px;
}
.cancel-btn {
  position: absolute;
  right: 15px;
  top: 10px;
}
</style>
